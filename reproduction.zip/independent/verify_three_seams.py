"""Independent proof certificate for the W-0117 three-seam shortening.
No 94 GB word expansion and no dependence on the searcher's cuts.csv.
Run from any directory: python3 verify_three_seams.py
"""
import hashlib,json,pathlib,subprocess
root=pathlib.Path(__file__).resolve().parent
original=root.parent/'W-0117.detour'
expected_encoded='6440069b52d81dfdf2a2d1bc5025a4e3df21402355a5e6bca8e392176c5f19c6'
assert hashlib.sha256(original.read_bytes()).hexdigest()==expected_encoded
subprocess.run(['g++','-O3','-std=c++17',str(root/'independent_seams.cpp'),'-o',str(root/'independent_seams')],check=True)
xz=subprocess.Popen(['xz','-dc',str(original)],stdout=subprocess.PIPE)
r=subprocess.run([str(root/'independent_seams')],stdin=xz.stdout,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True,text=True)
xz.stdout.close();xz.wait() # Parser deliberately stops just after the third seam; xz may receive SIGPIPE.
rows=[]
for line in r.stdout.splitlines():
 token,pos,gap,code,k,a,b=line.split();rows.append(dict(token_byte_offset=int(token),from_position=int(pos),default_steps_before=int(gap),code=int(code),old_weight=int(k),source=a,target=b))
expected=[(35465024,8018599985,14,'DCB015342A9876','0173426985ABCD'),(162125742,36587897101,11,'D1C02B459A3768','768234519ABCD0'),(222692179,50281547842,11,'0DC1B896425A37','A37689B5214CD0')]
alpha=set('0123456789ABCD')
def dist(a,b):return next(k for k in range(15) if a[k:]==b[:14-k])
for row,want in zip(rows,expected,strict=True):
 assert (row['token_byte_offset'],row['from_position'],row['old_weight'],row['source'],row['target'])==want
 a,b,k=row['source'],row['target'],row['old_weight'];assert len(a)==len(b)==14 and set(a)==set(b)==alpha
 text=a+b[-k:];assert text[-14:]==b
 interior=[(i,text[i:i+14]) for i in range(1,k) if len(set(text[i:i+14]))==14]
 assert not interior;assert dist(a,b)==k
 row['intermediate_permutation_windows']=interior
 row['old_seam_text']=text
new=[]
for source,target in [(0,1),(2,0),(1,2)]:
 a,b=rows[source]['source'],rows[target]['target'];k=dist(a,b);joined=a+b[-k:];assert joined[-14:]==b
 new.append(dict(from_seam=source+1,to_seam=target+1,source=a,target=b,weight=k,overlap=14-k,appended=b[-k:]))
old_cost=sum(x['old_weight'] for x in rows);new_cost=sum(x['weight'] for x in new)
assert old_cost==36 and new_cost==35
result=dict(baseline='https://superpermutations.com/w/W-0117',baseline_encoded_sha256=expected_encoded,baseline_length=93904752507,seams=rows,new_joins_in_word_order=new,old_join_cost=old_cost,new_join_cost=new_cost,saving=old_cost-new_cost,resulting_length=93904752507-old_cost+new_cost,original_block_order=['prefix','middle_1','middle_2','suffix'],new_block_order=['prefix','middle_2','middle_1','suffix'],coverage_claim='Every baseline permutation is retained: the removed seams contain no intermediate permutation window, and every within-block transition is unchanged. New joins preserve their endpoint permutations.',verification_scope='Independent parse of baseline through the third seam plus exact local checks and a coverage-preserving splice proof. Baseline all-permutation coverage relies on the published verified W-0117, not a new 14! bitmap scan.',parser_stats=r.stderr.strip())
(root/'independent_three_seam_verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
