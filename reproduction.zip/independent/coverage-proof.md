# Independent audit: ACBD reordering

Let W be the verified source word. For each selected cut, let p be the start offset of the left endpoint permutation and k its append cost, so the right endpoint permutation starts at p+k. Offsets are zero-based. Retain:

A=W[0:pi+14]
B=W[pi+ki:pj+14]
C=W[pj+kj:pk+14]
D=W[pk+kk:len(W)]

These are deliberately overlapping blocks when k<14. They are not a disjoint partition of the letters. Every original length14 window lies wholly inside one of these blocks unless its start is strictly between p and p+k at one of the three cuts. Independent script check.py reconstructs all such intermediate windows from the two endpoint permutations and verifies none is a permutation. Thus every original permutation occurrence is contained entirely in a retained block. Repeated occurrences and repeated rotation classes create no exception; the argument works on windows, not a presumed Hamiltonian path or class partition.

Reassemble A,C,B,D. At each join identify the matching suffix and prefix, without deleting any nonoverlapped content. Each block remains a contiguous substring of the assembled word. Therefore the reassembled word contains all permutations that W contained. New windows at joins may add occurrences; losing invalid intermediate original windows is harmless.

The independent local calculation gives new physical-order append costs12,14,9 versus original14,11,11. All blocks exceed14 characters, so gluing cannot erase or disrupt another join's endpoint window. Total retained-block length minus new overlap lengths gives93,904,752,506, exactly one below the source.

Scope: the mathematical lemma and local endpoint/cut arithmetic pass. Source positions are inherited from cutscan's Detour decoding; this independent check does not re-decode the entire93.9GB source or run full coverage check on a finished new Detour artifact. A valid submitted artifact must implement exactly these slices and bridges and have its own checksum/verification. Source verification is inherited from the public record, not independently rerun here.

Fresh public record check: https://superpermutations.com/api/records and https://superpermutations.com/api/words?n=14 both still identify W-0117 at93,904,752,507 as the shortest verified n14 word. JSON snapshots are retained beside this file. Live feed's newest n14 event is Jay Pantone's Nov19 improvement. The historical is_record field is true for many former records; the current records endpoint and minimum length, not that flag alone, establish current status.
