#include <array>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <unordered_map>
#include <vector>
using namespace std;using U=uint64_t;using P=array<unsigned char,14>;
U cursor=0;int n=14;U fac[15],period[15];P ident;array<P,15>complete;
int readbyte(){int c=getchar_unlocked();if(c<0)exit(2);cursor++;return c;}
U vi(){U x=0;int s=0,c;do{c=readbyte();x|=U(c&127)<<s;s+=7;}while(c&128);return x;}
P comp(P a,P b){P r;for(int j=0;j<n;j++)r[j]=a[b[j]];return r;}
P step(int k,U rank){P r;for(int j=0;j<n-k;j++)r[j]=j+k;vector<int>v;for(int j=k-1;j>=0;j--)v.push_back(j);for(int j=0;j<k;j++){U z=rank/fac[k-1-j];rank%=fac[k-1-j];r[n-k+j]=v.at(z);v.erase(v.begin()+z);}return r;}
P prefix(int level,U length){if(length==0)return ident;if(level==0){cerr<<"bad length";exit(2);}U q=length/period[level-1],rem=length%period[level-1];P block=comp(complete[level-1],step(level,0)),r=ident;for(U i=0;i<q;i++)r=comp(r,block);return comp(r,prefix(level-1,rem));}
U cost(U g){U r=g,d=1;for(int b=n;b>=2;b--){d*=b;r+=g/d;}return r;}
struct Key{U g,c;bool operator==(Key const&o)const{return g==o.g&&c==o.c;}};struct Hash{size_t operator()(Key const&x)const{return (x.g*0x9e3779b97f4a7c15ULL)^x.c;}};
struct Jump{P map;U chars;};
int main(){
 for(char c:string("Detour"))if(readbyte()!=c)return 2;if(readbyte()!=1||readbyte()!=14)return 2;string alphabet;for(int j=0;j<n;j++){alphabet+=char(readbyte());ident[j]=j;}fac[0]=period[0]=1;complete[0]=ident;
 for(int j=1;j<=n;j++)fac[j]=fac[j-1]*j;
 for(int k=1;k<n;k++){period[k]=period[k-1]*(n-k+1);P b=comp(complete[k-1],step(k,0)),r=ident;for(int z=0;z<n-k;z++)r=comp(r,b);complete[k]=comp(r,complete[k-1]);}
 U targets[]={35465024,162125742,222692179};int ti=0;P window;U length=0,tokens=0;unordered_map<Key,Jump,Hash>cache;
 while(ti<3){U at=cursor,g=vi(),c=vi();tokens++;
 if(c==1){if(g||length)return 2;for(int j=0;j<n;j++)window[j]=alphabet.find(readbyte());length=n;continue;}if(c<3){cerr<<"unexpected code\n";return 2;}
 Key key{g,c};auto it=cache.find(key);
 if(it==cache.end()){U r=c-3;int k=1;while(r>=fac[k])r-=fac[k++];Jump j{comp(prefix(n-1,g),step(k,r)),cost(g)+k};it=cache.emplace(key,j).first;}
 if(at==targets[ti]){
  P from=comp(window,prefix(n-1,g));U r=c-3;int k=1;while(r>=fac[k])r-=fac[k++];P to=comp(from,step(k,r));string a,b;for(int j=0;j<n;j++){a+=alphabet[from[j]];b+=alphabet[to[j]];}
  cout<<at<<' '<<length+cost(g)-n<<' '<<g<<' '<<c<<' '<<k<<' '<<a<<' '<<b<<'\n';cout.flush();ti++;
 }
 window=comp(window,it->second.map);length+=it->second.chars;
 }
 cerr<<"tokens_parsed="<<tokens<<" bytes_parsed="<<cursor<<" distinct_token_jumps="<<cache.size()<<" output_prefix_length="<<length<<'\n';
}
