# Independent verification of the one-letter improvement

The input is the published n=14 word W-0117, length 93,904,752,507. The downloaded Detour archive has SHA-256 `6440069b52d81dfdf2a2d1bc5025a4e3df21402355a5e6bca8e392176c5f19c6`, matching the Almanac API. The Almanac reports 14! distinct permutations, checked by both classcheck and bitmapcheck. This experiment does not rerun that global bitmap check.

A newly written parser (`independent_seams.cpp`) independently obtains the three endpoint pairs from the compressed input. It does not read the searcher's cuts table. It computes each default-run transformation recursively from the mixed-radix rule, rather than using the searcher's precomputed window table. It parses 74,249,255 tokens through the third seam.

| Seam | Token byte offset | Starting window's output index | Source | Target | Old cost |
|---|---:|---:|---|---|---:|
| 1 | 35,465,024 | 8,018,599,985 | DCB015342A9876 | 0173426985ABCD | 14 |
| 2 | 162,125,742 | 36,587,897,101 | D1C02B459A3768 | 768234519ABCD0 | 11 |
| 3 | 222,692,179 | 50,281,547,842 | 0DC1B896425A37 | A37689B5214CD0 | 11 |

All offsets are zero-based. Every endpoint consists of all 14 symbols exactly once. Exhaustive inspection of the 13, 10, and 10 interior windows in the three seam strings finds **no permutation window**. Thus no permutation is lost by removing the three transitions while retaining the four path blocks.

Write the original permutation-window path as P, edge 1, X, edge 2, Y, edge 3, Z. Keep every transition internal to P, X, Y, and Z. Reassemble the blocks as P, Y, X, Z. The new directed joins, in word order, are:

- Source 1 to target 2: overlap 2, append 12 letters.
- Source 3 to target 1: overlap 0, append 14 letters.
- Source 2 to target 3: overlap 5, append 9 letters.

The old join cost is 14 + 11 + 11 = 36. The new cost is 12 + 14 + 9 = 35. The result therefore has **93,904,752,506 letters** and retains every permutation covered by W-0117. This is a constructive upper-bound improvement, not a claim that the result is shortest.

The proof concerns a path of overlapping permutation windows, not naive slicing into disjoint character blocks. Endpoint overlaps must be handled when emitting the new word.

## Reproduction

Run `python3 verify_three_seams.py`. It verifies the input archive hash, compiles the independent parser, streams the Detour token container through it, verifies all endpoint/offset facts, exhaustively checks the discarded seam windows, recomputes maximal new overlaps, and writes `independent_three_seam_verification.json`. It never materializes the 94 GB word. The parser intentionally stops after the third seam, so its xz producer may terminate with SIGPIPE.

Earlier validation (`schedule_validation.json`) compared the default-run formula with explicit counters at 646,225 steps and independently decoded 13 published small fixtures, including SHA-256 checks. The separate local-neighborhood search found no improvements; it is not the source of this splice.

## Sources

- https://superpermutations.com/w/W-0117
- https://superpermutations.com/api/words/W-0117
- https://superpermutations.com/docs/format

The exact new Detour archive and its full decoded-word hash are separate deliverables of the coordinating experiment and are not claimed to have been checked by this report yet.
