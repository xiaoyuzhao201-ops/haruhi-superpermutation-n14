#!/usr/bin/env bash
set -euo pipefail
base=${1:-W-0117.detour}
result=${2:-n14-93904752506.detour}
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
expected_base=6440069b52d81dfdf2a2d1bc5025a4e3df21402355a5e6bca8e392176c5f19c6
printf '%s  %s\n' "$expected_base" "$base" | sha256sum -c -
xz -dc -- "$base" > "$tmp/base.tokens"
xz -dc -- "$result" > "$tmp/result.tokens"
python3 splice.py "$tmp/base.tokens" "$tmp/expected.tokens" --certificate "$tmp/splice.json"
python3 - "$tmp/expected.tokens" "$tmp/result.tokens" new_word_sha.txt <<'PY'
import os,sys
want,have,sha=sys.argv[1:]
assert os.path.getsize(have)==os.path.getsize(want)+32
with open(want,'rb') as a,open(have,'rb') as b:
    while x:=a.read(2**20): assert x==b.read(len(x))
    assert b.read().hex()==open(sha).read().strip()
print("New file encodes exactly the certified splice and expected digest trailer.")
PY
if [[ ${CHECK_FULL_HASH:-0} == 1 ]]; then
  g++ -std=c++20 -O3 -mssse3 hash_word.cpp -lcrypto -o "$tmp/hash_word"
  "$tmp/hash_word" "$tmp/base.tokens"
  "$tmp/hash_word" "$tmp/result.tokens"
fi
