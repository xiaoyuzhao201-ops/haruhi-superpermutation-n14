"""All one-defect chains with equal full-run flanks, for n=14.
Deficit ranges 1..12, flank lengths 1..16. Exact distinct necklace sets.
"""
from itertools import permutations
from collections import Counter
from functools import cache
import json

N=14
def necklace(p):
    i=p.index(0)
    return p[i:]+p[:i]

@cache
def row(p,length):
    classes=[]
    for offset in range(length):
        q=p[offset:N-1]+p[:offset]+p[-1:]
        classes.append(necklace(q))
    return frozenset(classes),q[-1:]+q[:-1]

@cache
def succ(end):
    return tuple(end[3:]+tail for tail in permutations(end[:3])
        if all(end[k:]!=(end[3:]+tail)[:-k] for k in (1,2)))

rows=[]
for d in range(1,N-1):
    for k in range(1,17):
        pattern=(N-1,)*k+(N-1-d,)+(N-1,)*k
        count=Counter()
        sample={}
        def walk(p,n,used,seq):
            count['states']+=1
            m,e=row(p,pattern[n])
            if used&m:return
            seq=seq+(p,)
            if n+1==len(pattern):
                count['valid']+=1
                if any(q[-1]!=seq[0][-1] for q in seq[1:]):
                    count['pivot_change']+=1
                    if not sample:sample['entries']=[''.join('0123456789ABCD'[x] for x in q) for q in seq]
                return
            for q in succ(e):walk(q,n+1,used|m,seq)
        walk(tuple(range(N)),0,frozenset(),())
        rows.append(dict(d=d,k=k,counts=dict(count),sample=sample))
    xs=rows[-16:]
    print(d,sum(x['counts']['states'] for x in xs),[x['k'] for x in xs if x['counts'].get('valid')],[x['k'] for x in xs if x['counts'].get('pivot_change')],flush=True)
print(row.cache_info(),succ.cache_info(),flush=True)
with open('extended_pivot.json','w') as f:json.dump(rows,f,indent=2);f.write('\n')
