/* Independent streaming reconstruction of the word hash from Detour tokens.
   Uses a SIMD permutation-index substitution for each default run, never
   materializing the whole word. Accepts uncompressed tokens, with or without trailer.
*/
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <openssl/evp.h>
#include <stdexcept>
#include <vector>
#include <tmmintrin.h>
using namespace std;
using U=uint64_t;
using P=array<unsigned char,16>;
int n;
array<U,17> fac{};
P step(const P& p,int w,U rank){
    P q{},pool{};
    copy(p.begin()+w,p.begin()+n,q.begin());
    for(int j=0;j<w;j++)pool[j]=p[w-1-j];
    int remain=w;
    for(int j=0;j<w;j++,remain--){
        int x=rank/fac[remain-1];rank%=fac[remain-1];
        if(x>=remain)throw runtime_error("invalid rank");
        q[n-w+j]=pool[x];
        for(int k=x;k+1<remain;k++)pool[k]=pool[k+1];
    }
    return q;
}
int main(int argc,char**argv){
    if(argc!=2)return 2;
    ifstream f(argv[1],ios::binary);
    if(!f)throw runtime_error("input");
    f.seekg(0,ios::end);auto sz=f.tellg();f.seekg(0);
    vector<unsigned char> raw(sz);if(!f.read((char*)raw.data(),sz))throw runtime_error("read");
    size_t pos=0;
    auto get=[&](){if(pos>=raw.size())throw runtime_error("EOF");return raw[pos++];};
    auto varint=[&](){U value=0;for(int sh=0;sh<64;sh+=7){auto ch=get();value|=U(ch&127)<<sh;if(ch<128)return value;}throw runtime_error("bad varint");};
    for(char c:string("Detour"))if(get()!=c)throw runtime_error("magic");
    if(get()!=1)throw runtime_error("version");
    n=get();if(n<2||n>16)throw runtime_error("n");
    array<bool,256> alphabet{};
    for(int j=0;j<n;j++){auto c=get();if(alphabet[c])throw runtime_error("alphabet");alphabet[c]=true;}
    fac[0]=1;for(int i=1;i<=n;i++)fac[i]=i*fac[i-1];
    P id{};for(int j=0;j<n;j++)id[j]=j;
    vector<unsigned char> timeline;
    vector<U> offsets{0};
    vector<P> shape{id};
    array<int,17> state{};
    auto extend=[&](U g){
        if(g>=fac[n]||g>10000000)throw runtime_error("default run bound");
        while(shape.size()<=g){
            int k=1;while(state[k]+k==n)++k;
            ++state[k];for(int x=1;x<k;x++)state[x]=0;
            P q=step(shape.back(),k,0);
            timeline.insert(timeline.end(),q.begin()+n-k,q.begin()+n);
            offsets.push_back(timeline.size());shape.push_back(q);
        }
    };
    EVP_MD_CTX* ctx=EVP_MD_CTX_new();
    if(!ctx||EVP_DigestInit_ex(ctx,EVP_sha256(),nullptr)!=1)throw runtime_error("hash init");
    vector<unsigned char> buf(1<<21);size_t z=0;U total=0,tokens=0;
    auto flush=[&](){
        if(EVP_DigestUpdate(ctx,buf.data(),z)!=1)throw runtime_error("hash update");
        total+=z;z=0;
    };
    auto emit=[&](unsigned char* p,size_t k){
        if(z+k>buf.size())flush();
        copy(p,p+k,buf.begin()+z);z+=k;
    };
    P p{};bool active=false;
    while(true){
        U g=varint(),code=varint();
        if(g){
            if(!active)throw runtime_error("gap before start");
            extend(g);
            const U k=offsets[g];
            const auto t=_mm_loadu_si128((const __m128i*)p.data());
            if(k+z+16>buf.size()){flush();if(k+16>buf.size())buf.resize(k+16);}
            U j=0;
            for(;j+16<=k;j+=16){
                auto a=_mm_loadu_si128((const __m128i*)(timeline.data()+j));
                _mm_storeu_si128((__m128i*)(buf.data()+z+j),_mm_shuffle_epi8(t,a));
            }
            for(;j<k;j++)buf[z+j]=p[timeline[j]];
            z+=k;P q{};for(int i=0;i<n;i++)q[i]=p[shape[g][i]];p=q;
        }
        if(code==0)break;
        ++tokens;
        if(code==1){
            P q{};array<bool,256> seen{};
            for(int i=0;i<n;i++){auto c=get();if(!alphabet[c]||seen[c])throw runtime_error("bad START");seen[c]=true;q[i]=c;}
            p=q;active=true;emit(p.data(),n);continue;
        }
        if(code==2)throw runtime_error("unexpected literal");
        if(!active)throw runtime_error("step before START");
        U rank=code-3;int k=1;
        while(k<=n && rank>=fac[k])rank-=fac[k++];
        if(k>n)throw runtime_error("bad weight");
        p=step(p,k,rank);emit(p.data()+n-k,k);
    }
    flush();unsigned char hash[EVP_MAX_MD_SIZE];unsigned m=0;
    if(EVP_DigestFinal_ex(ctx,hash,&m)!=1||m!=32)throw runtime_error("hash finalize");
    EVP_MD_CTX_free(ctx);
    if(raw.size()-pos!=0 && raw.size()-pos!=32)throw runtime_error("bad trailer length");
    if(raw.size()-pos==32 && !equal(hash,hash+m,raw.begin()+pos))throw runtime_error("trailer hash mismatch");
    cerr<<"length="<<total<<" tokens="<<tokens<<" trailer="<<(raw.size()-pos==32?"verified":"computed")<<'\n';
    for(unsigned i=0;i<m;i++)cout<<hex<<setfill('0')<<setw(2)<<unsigned(hash[i]);
    cout<<'\n';
}
