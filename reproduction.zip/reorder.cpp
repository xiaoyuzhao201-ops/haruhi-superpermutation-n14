#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <mutex>
#include <sstream>
#include <string>
#include <thread>
#include <vector>
using namespace std;
using U=uint64_t;
constexpr int N=14;
array<U,15> mask{};
struct Cut{U token,pos,a,b;int w;};
vector<Cut> v;
vector<unsigned char> costs;
int M;
unsigned char d(U a,U b){for(int k=0;k<N;k++)if((a&mask[N-k])==(b>>(4*k)))return k;return N;}
int get(int i,int j){return costs[(U)i*M+j];}
atomic<int> best{0};
mutex mu;
void report(int i,int j,int k,int mode,int diff){
    if(diff<=0)return;
    lock_guard lk(mu);
    if(diff<=best.load())return;
    best.store(diff);
    cout<<"saving="<<diff<<" mode="<<mode<<" i="<<i<<" j="<<j<<" k="<<k<<"\n";
    for(int x:{i,j,k})cout<<x<<" token_byte_offset="<<v[x].token<<" position="<<v[x].pos<<" from="<<hex<<v[x].a<<" to="<<v[x].b<<dec<<" old="<<v[x].w<<"\n";
    cout<<"new_costs="<<get(i,j)<<','<<get(j,k)<<','<<get(k,i)<<endl;
}
int main(int argc,char**argv){
    if(argc<2)return 2;
    int range=argc>2?stoi(argv[2]):128, threads=argc>3?stoi(argv[3]):8;
    U random_draws=argc>4?stoull(argv[4]):100000000;
    int min_seam=argc>5?stoi(argv[5]):5;
    for(int i=1;i<=N;i++)mask[i]=(mask[i-1]<<4)|15;
    ifstream f(argv[1]);string s;getline(f,s);
    while(getline(f,s)){replace(s.begin(),s.end(),',',' ');istringstream q(s);Cut c;q>>c.token>>c.pos>>c.a>>c.b>>c.w;if(!q)throw logic_error("bad input");if(c.w>=min_seam)v.push_back(c);}
    M=v.size();costs.resize((U)M*M);
    vector<thread> work;
    for(int t=0;t<threads;t++)work.emplace_back([&,t]{
        for(int i=t;i<M;i+=threads) for(int j=0;j<M;j++)costs[(U)i*M+j]=d(v[i].a,v[j].b);
    });
    for(auto&t:work)t.join();
    work.clear();
    cerr<<"matrix_done size="<<M<<"\n";

    // Fully exhaustive reversal of the three interior blocks at four cuts.
    // Old bridge weights are split into two pairs; benefit occurs exactly
    // when the sum of gains for two crossing intervals is positive.
    auto pointgain=[&](int a,int b){return v[a].w+v[b].w-get(a,b)-get(b,a);};
    int pair_max=-100;
    U ppositive=0;
    for(int b=1;b<M;b++)for(int a=0;a<b;a++){
        int gain=pointgain(a,b);pair_max=max(pair_max,gain);ppositive+=gain>0;
    }
    struct Pair{int score,a,b;};
    int size=1;while(size<M)size*=2;
    vector<Pair> segtree(size*2,{-100,-1,-1});
    auto activate=[&](int i,int k,int gain){
       for(int l=i+1+size,r=k+size;l<r;l/=2,r/=2) {
          if(l&1){if(gain>segtree[l].score)segtree[l]={gain,i,k};++l;}
          if(r&1){--r;if(gain>segtree[r].score)segtree[r]={gain,i,k};}
       }
    };
    auto query=[&](int j){
       Pair ans{-100,-1,-1};
       for(int l=j+size;l;l/=2)if(segtree[l].score>ans.score)ans=segtree[l];
       return ans;
    };
    U nactive=0,nqueries=0;
    int best4=0;
    if(pair_max>0)for(int l=3;l<M;l++){
      int k=l-1;
      for(int i=0;i<k-1;i++){
        int gain=pointgain(i,k);
        if(gain+pair_max>0){activate(i,k,gain);++nactive;}
      }
      for(int j=1;j<l-1;j++){
        int gain=pointgain(j,l);
        if(gain+pair_max<=0)continue;
        ++nqueries;
        auto pair=query(j);
        if(pair.score+gain>best4){
          best4=pair.score+gain;
          cout<<"four_cut_saving="<<best4<<" i="<<pair.a<<" j="<<j<<" k="<<pair.b<<" l="<<l<<"\n";
          for(int x:{pair.a,j,pair.b,l})cout<<x<<" token_byte_offset="<<v[x].token<<" position="<<v[x].pos<<" from="<<hex<<v[x].a<<" to="<<v[x].b<<dec<<" old="<<v[x].w<<"\n";
          cout<<flush;
        }
      }
    }
    cerr<<"exact_four_cut_reverse=yes pair_max="<<pair_max<<" positive_pairs="<<ppositive<<" interval_activations="<<nactive<<" interval_queries="<<nqueries<<" best_four_saving="<<best4<<"\n";

    if(argc>6 && string(argv[6])=="exact3"){
       constexpr int low=-6,high=14,bins=high-low+1;
       if(M>65535)throw logic_error("16-bit index too small");
       using B=array<vector<uint16_t>,bins>;
       vector<B> out(M),in(M);
       auto gain=[&](int a,int b){return v[a].w-get(a,b);};
       for(int a=0;a<M;a++)for(int b=0;b<M;b++)if(a!=b){
          int g=gain(a,b);
          if(g>=low){out[a][g-low].push_back(b);in[b][g-low].push_back(a);}
       }
       array<U,bins> histogram{};
       for(auto&b:out)for(int j=0;j<bins;j++)histogram[j]+=b[j].size();
       for(int j=0;j<bins;j++)cerr<<"gain "<<j+low<<" count "<<histogram[j]<<"\n";
       vector<U> checked(threads);
       for(int t=0;t<threads;t++)work.emplace_back([&,t]{
          for(int i=t;i<M;i+=threads)for(int g=1;g<=high;g++)for(int j:out[i][g-low]){
             int floor=(1-g)/2;
             auto check=[&](auto const& vec,int lo,int hi){
                 auto it=lower_bound(vec.begin(),vec.end(),lo), end=lower_bound(it,vec.end(),hi);
                 for(;it!=end;++it){
                    int k=*it;
                    // Any improvement has an edge of maximum positive gain.
                    // Skip failures cheaply, but keep ties and allow repeats in coverage counts.
                    ++checked[t];
                    int a=gain(j,k), b=gain(k,i);
                    if(a>g||b>g)continue;
                    int diff=g+a+b;
                    if(diff>best.load(memory_order_relaxed)){
                       array<int,3>x{i,j,k};sort(x.begin(),x.end());report(x[0],x[1],x[2],3,diff);
                    }
                 }
             };
             for(int h=floor;h<=g;h++){
                 if(i<j){
                    check(out[j][h-low],0,i);check(out[j][h-low],j+1,M);
                    check(in[i][h-low],0,i);check(in[i][h-low],j+1,M);
                 } else {
                    check(out[j][h-low],j+1,i);check(in[i][h-low],j+1,i);
                 }
             }
          }
       });
       for(auto&t:work)t.join();
       U total=0;for(auto x:checked)total+=x;
       cerr<<"all_three_cut=yes checked_extensions_with_repeats="<<total<<" best_saving="<<best.load()<<"\n";
       return 0;
    }
    vector<array<U,2>> checks(threads);
    for(int t=0;t<threads;t++)work.emplace_back([&,t]{
        for(int i=t;i<M-2;i+=threads){
            for(int j=i+1;j<min(M-1,i+range);j++){
                int pre=v[i].w+v[j].w-get(i,j);
                for(int k=j+1;k<min(M,i+range+1);k++){
                    ++checks[t][0];
                    int diff=pre+v[k].w-get(j,k)-get(k,i);
                    if(diff>best.load(memory_order_relaxed))report(i,j,k,1,diff);
                }
            }
        }
        U seed=0xede76aae37cf9f7aULL^U(t+1);
        auto draw=[&](){seed^=seed<<13;seed^=seed>>7;seed^=seed<<17;return int(seed%M);};
        for(U n=t;n<random_draws;n+=threads){
            array<int,3>a{draw(),draw(),draw()};sort(a.begin(),a.end());
            int i=a[0],j=a[1],k=a[2];if(i==j||j==k)continue;
            ++checks[t][1];
            int diff=v[i].w+v[j].w+v[k].w-get(i,j)-get(j,k)-get(k,i);
            if(diff>best.load(memory_order_relaxed))report(i,j,k,2,diff);
        }
    });
    for(auto&t:work)t.join();
    U local=0,rand=0;for(auto a:checks){local+=a[0];rand+=a[1];}
    cerr<<"exact_local_triples="<<local<<" random_valid_draws="<<rand<<" range="<<range<<" best_saving="<<best.load()<<"\n";
}
