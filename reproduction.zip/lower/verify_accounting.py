from fractions import Fraction as F
from math import factorial,ceil
from pathlib import Path
import json
from geometry import row,nextrows
p0=tuple(range(14));lens=[13]*11+[11]+[13]*11
solutions=[]
def visit(p,i,used,path):
 m,e=row(p,lens[i])
 if m&used:return
 path=path+[p]
 if i+1==len(lens):solutions.append(path);return
 for q in nextrows(e):visit(q,i+1,used|m,path)
visit(p0,0,set(),[])
assert len(solutions)==1
# The n7-shaped inequality r <= n-2+2a would give16, but r=23 valid.
f3=sum(factorial(i) for i in (14,13,12));delta=F(1138,6229);beta=F(15816,6229);alpha=13-delta
base=14+15*factorial(13)-3
bound=base+ceil((factorial(13)-beta)/alpha)
assert bound==93891141149
r=dict(F3=f3,general_bound=bound,published_bound=bound+1,
 classic_bound=f3+11,delta=str(delta),beta=str(beta),alpha=str(alpha),
 next_length_to_exclude=bound+1,next_budget=bound+1-base,
 next_capacity_margin=str(alpha*(bound+1-base)+beta-factorial(13)),
 next_scalar_energy=str((alpha*(bound+1-base)+beta-factorial(13))*F(6229,15)),
 counterexample_to_naive_n7_capacity=dict(entries=solutions[0],lengths=lens,rows=23,holes=2,classes=297))
Path(__file__).with_name('accounting_results.json').write_text(json.dumps(r,indent=2));print(json.dumps({k:v for k,v in r.items() if k!='counterexample_to_naive_n7_capacity'},indent=2))

# Proposed finite certificate arithmetic only; inequality is UNPROVED.
q,c,b0=9483,500,36000
A=11*q-c
d=F(2*q,A);be=F(24*q+b0,A)
proposed=base+ceil((factorial(13)-be)/(13-d))
assert proposed==93891141151
Path(__file__).with_name('proposed_certificate.json').write_text(json.dumps(dict(status='unproved target',n=14,q=q,c=c,b0=b0,A=A,delta=str(d),beta=str(be),conditional_lower_bound=proposed),indent=2))
