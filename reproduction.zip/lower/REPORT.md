# n=14 lower-bound investigation

No global lower-bound improvement was proved. No n=14 superpermutation was constructed. All computation here is cloud-only.

## Primary-source baseline

Pinned Pantone source:
https://github.com/jaypantone/2026-10-superpermutation-lower-palomar/blob/8cc371be7ad7dc47252e45ffbda633a85776d596/README.md

Finite paper downloaded as `finite.tex`:
https://raw.githubusercontent.com/jaypantone/2026-10-superpermutation-lower-palomar/8cc371be7ad7dc47252e45ffbda633a85776d596/papers/finite/finite-lower-bounds.tex

It establishes S(14)>=93,891,141,150 for arbitrary covering words. General formula gives 93,891,141,149; the extra unit comes from an equality-case compatibility contradiction. Standard Lean axioms only are reported; I did not rebuild Lean. The repository distinguishes successful individual replay diagnostics from the combined protected Palomar workflow, not yet run at that snapshot. This exceeds Halfar's separately reported October24 bound93,891,141,126.

## What transfers from n=7

Rotation classes, runs, disjoint-class overlap checks and exact seam generation transfer. A run contains up to13 classes at n14. It is unsafe to transfer the n7 capacity r<=5+2a by replacing5 with12. `accounting_results.json` contains a concrete normalized n14 chain of23 runs with only2 holes, occupying297 distinct classes: eleven full runs, one11-class run, eleven full runs. Every seam has exact cost3. A naive r<=12+2a would give16 and is false.

## Exhaustive bounded local experiment

`local_pivot.py` checks all343 ordered length triples from7..13, normalizing only the first entry. At each seam it checks all6 permutations of the last3 free symbols and verifies maximal overlap cost3. Used cyclic classes are stored explicitly, not hashed approximately.

Counts:2058 pair attempts (repeated across third lengths),7392 triple attempts after pair rejection,4004 disjoint triples,3710 with a pivot change. The cheapest pivot-changing pattern has deficits(0,2,0). Thus an isolated deficit2 bracketed by only one full run on each side does NOT force constant pivot.

`flanking_pivot.py` exhausts all66 patterns(0^k,d,0^k), d=1..6, k=1..11. For d1 no disjoint realization exists. For d2..6 and k>=d exactly one normalized realization exists and its pivot is constant. For every k<d there are pivot-changing realizations. Full counts are in JSON. These are exact finite Python searches, not formal Lean certificates.

A rigorous bounded-subcase consequence follows with the standard adjacent-full pivot lemma: a complete light segment whose nonzero deficits lie in2..6, with each deficit d flanked by at least d full runs on both sides, is impossible if any deficit is positive. The checked local pieces force one common pivot; every run occupies at least7 of13 slots in its pivot insertion loop, so two disjoint runs cannot share a loop. Complete coverage would require every run to be full. This is a generalization/reproduction of the published compatibility mechanism, not a claim of mathematical novelty or a new global bound.

## Exact next target, not a proof

F3(14)=93,884,313,600. At length93,891,141,150 the available budget is485,829,139. With existing alpha=79839/6229 and beta=15816/6229 the capacity margin is81237/6229, not1398/6229. Hence the old small-margin equality argument cannot simply be repeated.

A precise new finite-certificate target in Halfar's window framework is

- n=14, q=9483, c=500, b0=36000;
- A=11q-c=103813;
- desired hereditary capacity:103813 D >=18966 r-263592.

Proving the corresponding all-length window inequality, including the framework's separate full-tail exclusion and its completeness conditions, would imply S(14)>=93,891,141,151. Merely testing short chains cannot establish it. In the p,t formula this is p36,t9483/250. Exact arithmetic threshold is t<177515870/4679823; the suggested t is slightly below it. There is no assertion here that this candidate inequality is true. It might admit a finite counterexample.

## Reproduction

python haruhi14_lower/local_pivot.py
python haruhi14_lower/flanking_pivot.py
python haruhi14_lower/verify_accounting.py

All use Python standard library. Scripts finish well under a second on this environment. The JSON files retain counts, finite scope and witness entries. `SHA256SUMS.txt` identifies the Python sources.
