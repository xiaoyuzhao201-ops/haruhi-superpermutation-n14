"""Exhaustive normalized two/three-run census on n=14 for run lengths7..13.
Runs comprise consecutive distinct rotation classes under rotation of first13
entries; seams have exact overlap cost3; all rotation classes globally distinct.
Only first entry normalized. No all-length or global-word completeness claim.
"""
import itertools,json,time
from collections import Counter
from pathlib import Path
N=14; root=Path(__file__).resolve().parent

def cls(p):
 i=p.index(0);return p[i:]+p[:i]
def row(p,l):
 occ=set()
 for _ in range(l):
  last=p;occ.add(cls(p));p=p[1:13]+p[:1]+p[13:]
 return occ,last[-1:]+last[:-1]
def cost(p,q):return next(k for k in range(1,15) if p[k:]==q[:-k])
def nextrows(end):
 for tail in itertools.permutations(end[:3]):
  q=end[3:]+tail
  if cost(end,q)==3:yield q
