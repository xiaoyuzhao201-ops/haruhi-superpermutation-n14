"""Exhaustive normalized two/three-run census on n=14 for run lengths7..13.
Runs comprise consecutive distinct rotation classes under rotation of first13
entries; seams have exact overlap cost3; all rotation classes globally distinct.
Only first entry normalized. No all-length or global-word completeness claim.
"""
import itertools,json,time
from collections import Counter
from pathlib import Path
N=14; root=Path(__file__).resolve().parent

def cls(p):
 i=p.index(0);return p[i:]+p[:i]
def row(p,l):
 occ=set()
 for _ in range(l):
  last=p;occ.add(cls(p));p=p[1:13]+p[:1]+p[13:]
 return occ,last[-1:]+last[:-1]
def cost(p,q):return next(k for k in range(1,15) if p[k:]==q[:-k])
def nextrows(end):
 for tail in itertools.permutations(end[:3]):
  q=end[3:]+tail
  if cost(end,q)==3:yield q
stats=Counter(); patterns={}; examples={};start=time.monotonic()
for lens in itertools.product(range(7,14),repeat=3):
 h=tuple(13-l for l in lens);cnt=Counter();p=tuple(range(14));a,e=row(p,lens[0])
 for q in nextrows(e):
  b,f=row(q,lens[1]);stats['pair_attempts']+=1
  if a&b:continue
  for r in nextrows(f):
   c,g=row(r,lens[2]);stats['triple_attempts']+=1
   if c&(a|b):continue
   flags=(q[-1]!=p[-1],r[-1]!=q[-1])
   cnt[str(flags)]+=1;stats['disjoint_triples']+=1
   if any(flags):
    stats['pivot_changing_triples']+=1
    key=str(h)
    examples.setdefault(key,dict(entries=[p,q,r],lengths=lens,pivots=[p[-1],q[-1],r[-1]]))
 patterns[str(h)]=dict(cnt)
result=dict(scope=__doc__,stats=dict(stats),elapsed_seconds=time.monotonic()-start,patterns=patterns,pivot_changing_examples=examples)
(root/'local_pivot_results.json').write_text(json.dumps(result,indent=2))
print(dict(stats)); print('minimum total deficit pivot-changing triple',min(sum(eval(x)) for x in examples))
for h in sorted((eval(k) for k in examples),key=lambda h:(sum(h),h))[:30]: print(h,patterns[str(h)])
