from geometry import row,nextrows
from pathlib import Path
import json
out=[]
for d in range(1,7):
 for k in range(1,12):
  ls=[13]*k+[13-d]+[13]*k
  totals=[0,0];example=[]
  def walk(p,i,used,pivots):
   m,e=row(p,ls[i])
   if m&used:return
   ps=pivots+[p[-1]]
   if i==len(ls)-1:
    totals[0]+=1
    if len(set(ps))>1:
     totals[1]+=1
     if not example:example.extend(ps)
    return
   for q in nextrows(e):walk(q,i+1,used|m,ps)
  walk(tuple(range(14)),0,set(),[])
  out.append(dict(deficit=d,full_runs_each_side=k,valid=totals[0],pivot_changing=totals[1],example_pivots=example))
Path(__file__).with_name('flanking_pivot_results.json').write_text(json.dumps(out,indent=2))
for d in range(1,7): print(d,[(x['full_runs_each_side'],x['valid'],x['pivot_changing']) for x in out if x['deficit']==d])
