#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <iterator>
#include <stdexcept>
#include <string>
#include <vector>
using namespace std;
using U=uint64_t;
using P=array<unsigned char,16>;
int N;
array<U,17> fac{},mask{};
string alphabet;
P ident;
P nextp(P p,int k,U rank){
    P out{}, ref{};
    for(int j=0;j<N-k;j++)out[j]=p[j+k];
    for(int j=0;j<k;j++)ref[j]=p[k-1-j];
    for(int j=0;j<k;j++){
        const U base=fac[k-1-j], digit=rank/base;
        rank%=base;
        if(digit>=U(k-j))throw runtime_error("rank");
        out[N-k+j]=ref[digit];
        for(int z=digit;z<k-1-j;z++)ref[z]=ref[z+1];
    }
    return out;
}
U enc(P const& p){U v=0;for(int j=0;j<N;j++)v=v*16+p[j];return v;}
string txt(P const& p){string s;for(int j=0;j<N;j++)s+=alphabet.at(p[j]);return s;}
int dist(U a,U b){
    for(int k=0;k<N;k++)if((a&mask[N-k])==(b>>(4*k)))return k;
    return N;
}
struct Cut { U token,pos,a,b; int weight; };
int main(int argc,char**argv){
    if(argc<2) return 2;
    ifstream in(argv[1],ios::binary);
    vector<unsigned char> raw((istreambuf_iterator<char>(in)),{});
    size_t at=0;
    auto get=[&](){if(at==raw.size())throw runtime_error("EOF");return raw[at++];};
    auto v=[&](){U res=0;for(int s=0;s<64;s+=7){ U b=get();res|=(b&127)<<s;if(b<128)return res;}throw runtime_error("varint");};
    for(char ch:string("Detour"))if(get()!=ch)throw runtime_error("magic");
    if(get()!=1)throw runtime_error("version");
    N=get();if(N<2||N>16)throw runtime_error("N");
    fac[0]=1;
    for(int i=1;i<=N;i++){ fac[i]=fac[i-1]*i;mask[i]=(mask[i-1]<<4)|15; }
    for(int i=0;i<N;i++){alphabet+=char(get());ident[i]=i;}
    vector<P> forms{ident};vector<U> lengths{0};
    array<int,17> counter{};
    auto extend=[&](U goal){
       if(goal>=fac[N]||goal>10000000)throw runtime_error("default block beyond bound");
       while(forms.size()<=goal){
           int k=1;while(counter[k]==N-k)++k;
           ++counter[k];for(int j=1;j<k;j++)counter[j]=0;
           forms.push_back(nextp(forms.back(),k,0));lengths.push_back(lengths.back()+k);
       }
    };
    P p{};U length=0,ix=0,trivial=0;bool active=false;
    array<U,17> tokens{},cuttable{},cutmatch{};
    vector<Cut> cuts;
    for(;;++ix){
       const U token_at=at;
       U gap=v(),code=v();
       if(gap){
           if(!active)throw runtime_error("no start");
           extend(gap);const auto& f=forms[gap];P q{};
           for(int j=0;j<N;j++)q[j]=p[f[j]];
           p=q;length+=lengths[gap];
       }
       if(code==0)break;
       if(code==1){if(active||length!=0)throw runtime_error("second START");for(int j=0;j<N;j++)p[j]=alphabet.find(get());length+=N;active=true; continue;}
       if(code==2)throw runtime_error("literal outside scope");
       U rank=code-3;int k=1;while(k<=N&&rank>=fac[k])rank-=fac[k++];
       if(k>N)throw runtime_error("weight");
       ++tokens[k];
       P q=nextp(p,k,rank);
       if(k>=4){
           array<int,16> count{};
           for(int j=0;j<N;j++)count.at(p[j])++;
           bool inter=false;
           for(int t=0;t<k-1;t++){
               --count.at(p[t]);++count.at(q[N-k+t]);
               if(all_of(count.begin(),count.begin()+N,[](int c){return c==1;})){inter=true;break;}
           }
           if(!inter){
               ++cuttable[k]; const U a=enc(p),b=enc(q);
               if(dist(a,b)==k)++cutmatch[k];
               if(dist(a,b)<k){
                   ++trivial;
                   cerr<<"shorten_single token="<<ix<<" pos="<<(length-N)<<" source="<<txt(p)<<" target="<<txt(q)<<" old="<<k<<" new="<<dist(a,b)<<"\n";
               }
               cuts.push_back({token_at,length-N,a,b,k});
           }
       }
       p=q;length+=k;
    }
    if(raw.size()-at!=32)throw runtime_error("end/trailer");
    cerr<<"length="<<length<<" tokens="<<ix<<" cuts="<<cuts.size()<<" simple_shortenings="<<trivial<<" max_default="<<forms.size()-1<<"\n";
    for(int k=1;k<=N;k++) cerr<<k<<" detours="<<tokens[k]<<" cuttable="<<cuttable[k]<<" metric_matches="<<cutmatch[k]<<'\n';
    cout<<"token_byte_offset,from_pos,from_packed,to_packed,weight\n";
    for(auto c:cuts)cout<<c.token<<','<<c.pos<<','<<c.a<<','<<c.b<<','<<c.weight<<'\n';
}
