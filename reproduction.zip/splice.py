"""Reproduce a one-letter shortening of Jay Pantone's W-0117.
The output is a raw Detour token stream without its 32-byte word-SHA trailer.
Use hash_word.cpp to compute the trailer before xz compression.
"""
import argparse,json,math,mmap, pathlib
from itertools import permutations

ap=argparse.ArgumentParser()
ap.add_argument('src',type=pathlib.Path)
ap.add_argument('out',type=pathlib.Path)
ap.add_argument('--certificate',type=pathlib.Path,default=pathlib.Path('splice.json'))
args=ap.parse_args()
N=14
known_digest='f23ee94691d3c500ddd08d46aa800f07437bd5269334be6bb6a3e39d05d70ba3'
cuts=[
 (35465024,8018599985,'dcb015342a9876','0173426985abcd',14),
 (162125742,36587897101,'d1c02b459a3768','768234519abcd0',11),
 (222692179,50281547842,'0dc1b896425a37','a37689b5214cd0',11)]
def readint(mm,i):
    t=0
    for s in range(0,64,7):
        b=mm[i];i+=1;t|=(b&127)<<s
        if b<128:return t,i
    raise ValueError("varint")
def uleb(t):
    b=[]
    while t>=128:b.append((t&127)|128);t>>=7
    return bytes(b+[t])
A='0123456789abcd'
def rank(seq,items):
    items=list(items);ans=0
    for x in seq:
        i=items.index(x);ans+=i*math.factorial(len(items)-1);items.pop(i)
    return ans
def code_for(p,q,k):
    assert sorted(p)==sorted(q)==list(A) and p[k:]==q[:N-k]
    return 3+sum(math.factorial(j) for j in range(1,k))+rank(q[N-k:],p[:k][::-1])
def d(p,q):
    return next(i for i in range(N+1) if p[i:]==q[:N-i])
def default_next(g):
    for k in range(1,N):
        g,rem=divmod(g,N-k+1)
        if rem<N-k:return k
    return None
with args.src.open('rb') as f, mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as data:
    assert data[:22]==b'Detour\1\x0e0123456789ABCD' and data[-32:].hex()==known_digest
    old_tokens=[]; endpoints=[]; removed=[]
    for off,pos,p,q,w in cuts:
        g,mi=readint(data,off)
        code,after=readint(data,mi)
        assert code==code_for(p,q,w)
        assert w==d(p,q)
        local=p+q[N-w:]
        windows=[local[j:j+N] for j in range(1,w)]
        assert all(sorted(x)!=list(A) for x in windows)
        removed.append(windows)
        old_tokens.append((g,mi,after))
        endpoints.append((p,q,w))
    order=(0,2,1) # source cut indices in emission order
    target={0:1,2:0,1:2}
    g0,m0,e0=old_tokens[0];g1,m1,e1=old_tokens[1];g2,m2,e2=old_tokens[2]
    ranges=[(0,cuts[0][0]),(e1,cuts[2][0]),(e0,cuts[1][0]),(e2,len(data)-32)]
    records=[]
    with args.out.open('wb') as out:
        mv=memoryview(data)
        for (lo,hi),i in zip(ranges,order):
            out.write(mv[lo:hi])
            j=target[i];p=endpoints[i][0];q=endpoints[j][1]
            k=d(p,q);code=code_for(p,q,k)
            g,mi,_=old_tokens[i]
            assert not(code==3+sum(math.factorial(j) for j in range(1,k)) and default_next(g)==k)
            out.write(uleb(g));out.write(uleb(code))
            records.append(dict(original_source_cut=i,original_target_cut=j,source=p.upper(),target=q.upper(),cost=k,default_steps=g,code=code))
        lo,hi=ranges[-1];out.write(mv[lo:hi]);mv.release()
    old=sum(x[2] for x in endpoints);new=sum(x['cost'] for x in records)
    assert old==36 and new==35
    dct=dict(base_id='W-0117',base_sha256=known_digest,base_length=93904752507,new_length=93904752507-old+new,old_cut_cost=old,new_cut_cost=new,
             cuts=[dict(token_offset=a,from_pos=b,source=c.upper(),target=d.upper(),weight=e,interior=[x.upper() for x in vs]) for (a,b,c,d,e),vs in zip(cuts,removed)],
             blocks_order='ACBD',changed_transitions=records)
    args.certificate.write_text(json.dumps(dct,indent=2)+'\n')
    print('old/new cost',old,new,'length',dct['new_length'],'emission order',[(r['original_source_cut'],r['original_target_cut'],r['cost']) for r in records])
